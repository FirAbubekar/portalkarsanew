<!doctype html>
<html class="no-js" lang="en">

<head>
	<?php $this->load->view('portal/template/header_css'); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/pendukung/index.css">


</head>

<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

	<div class="wrapper">
		<!--Header Area Start-->
	<?php $this->load->view('portal/template/menu');?>
		<!--Header Area End-->
		<!--Slider Area Start-->
		
	
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
			<!-- Indicators -->
			<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>
			</ol>

			<!-- Wrapper for slides -->
			<style>
    			@media (max-width:700px) {
                  .carousel-inner {
                    position: relative;
                    width: 100%;
                    height: 250px;
                    overflow: hidden;
                } 
                .pt-120 { padding-top: 100% }
                }
                
                @media (max-width:700px) {
                .pt-120 { padding-top: 110% }
                }
                
                @media (min-width:700px) and (max-width:800px) {
                  .carousel-inner {
                    position: relative;
                    width: 100%;
                    height: 350px;
                    overflow: hidden;
                  }
                  .pt-120 { padding-top: 100% }
                }
                @media (max-width:1000px) {
                  .pt-120 { padding-top: 100% }
                }
                @media (min-width:800px) and (max-width:1200px) {
                  .carousel-inner {
                    position: relative;
                    width: 100%;
                    height: 400px;
                    overflow: hidden;
                  }
                }
				.title{
					font-size: 40px;  
					color: #009982;
				}
				
			@media (max-width:700px) {
				.title{
					font-size: 18px;  
					color: #009982;
					padding-bottom: 0px;
					padding-left: 5px;
					padding-right: 5px;
				}
				.text-block {
					left: 29px;
					right: 29px;
					top: 10px;
					width: 90%;
					padding-left: 20px;
					padding-right: 20px;
					padding-top: 20px;
					padding-bottom: 20px;
				}
				.descbox{
					padding-top: 10px;
					font-size: 10px;
					color: #5B5C5C;
				}

			} 
			</style>
			<div class="carousel-inner">
				<div class="item active">
					<div class="text-block">
						<h2 class="title">SELAMAT DATANG</h2>
						<h3 class="subtitle" style="font-weight: 520; color: #005145;">Rumah Sakit Umum Karsa Husada Batu</h3>
						<p class="descbox">Rumah Sakit Umum Karsa Husada Batu selalu memberi pelayanan prima agar menjadi
							rumah sakit pilihan utama masyarakat khususnya di Kota Batu</p>
					</div>
					<img src="<?php echo base_url();?>assets_portal/img/slider/bg1.jpg" alt="Los Angeles" style="width:100%;">
				</div>

				<div class="item">
					<div class="text-block">
						<h2 class="title">SELAMAT DATANG</h2>
						<h3 class="subtitle" style="font-weight: 520; color: #005145;">Rumah Sakit Umum Karsa Husada Batu</h3>
						<p class="descbox">Rumah Sakit Umum Karsa Husada Batu selalu memberi pelayanan prima agar menjadi
							rumah sakit pilihan utama masyarakat khususnya di Kota Batu</p>
					</div>
					<img src="<?php echo base_url();?>assets_portal/img/slider/bg2.JPG" alt="Chicago" style="width:100%;">
				</div>

				<div class="item">
					<div class="text-block">
						<h2 class="title">SELAMAT DATANG</h2>
						<h3 class="subtitle" style="font-weight: 520; color: #005145;">Rumah Sakit Umum Karsa Husada Batu</h3>
						<p class="descbox">Rumah Sakit Umum Karsa Husada Batu selalu memberi pelayanan prima agar menjadi
							rumah sakit pilihan utama masyarakat khususnya di Kota Batu</p>
					</div>
					<img src="<?php echo base_url();?>assets_portal/img/slider/bg3.jpg" alt="New york" style="width:100%;">
				</div>
			</div>

			<!-- Left and right controls -->
			<a class="left carousel-control" href="#myCarousel" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
		<!--Slider Area End-->
		<!--Feature Area Start-->
		<div class="timeline-area bg-img">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="view-all-history">
							<br>
							<br>
								<h2 style="color: #005145;text-align: center; letter-spacing: 0.05em;">FASILITAS</h2>
							<br>
							<br>
							<br>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12 col-lg-6 col-xl-3">
						<!--Single Timeline Strat-->
						<a href="<?php echo base_url('pelayanan/rawat_jalan'); ?>">
						<div class="single-timeline mb-50 d-flex align-items-center">
							<div class="timeline-frame">
								<center><img src="<?php echo base_url();?>assets_portal/img/icon/ic_rawat_jalan.png"></center>
								<br>
								<div class="timeline-content">
									<div class="nama_t">RAWAT JALAN</div>
									<p class="d_fasilitas">22 Poli Dengan Peralatan yang Lengkap</p>
								</div>
							</div>
							<br>

						</div>
						</a>
						<!--Single Timeline End-->
					</div>
					<div class="col-md-12 col-lg-6 col-xl-3">
						<!--Single Timeline Strat-->
						<a href="<?php echo base_url('pelayanan/rawat_inap'); ?>">
						<div class="single-timeline mb-50 d-flex align-items-center">
							<div class="timeline-frame">
								<center><img src="<?php echo base_url();?>assets_portal/img/icon/ic_rawat_inap.png"></center>
								<br>
								<div class="timeline-content">
									<div class="nama_t">RAWAT INAP</div>
									<p class="d_fasilitas">Ruang Rawat Inap dengan Fasilitas yang Memadai</p>
								</div>
							</div>
							<br>

						</div>
						</a>
						<!--Single Timeline End-->
					</div>
					<div class="col-md-12 col-lg-6 col-xl-3">
						<!--Single Timeline Strat-->
						<a href="<?php echo base_url('pelayanan/penunjang'); ?>">
						<div class="single-timeline mb-50 d-flex align-items-center">
							<div class="timeline-frame">
								<center><img src="<?php echo base_url();?>assets_portal/img/icon/ic_penunjang.png"></center>
								<br>
								<div class="timeline-content">
									<div class="nama_t">PENUNJANG</div>
									<p class="d_fasilitas">Alat Penunjang Baru dan Akurat</p>
								</div>
							</div>
							<br>
						</div>
						</a>
						<!--Single Timeline End-->
					</div>
					<div class="col-md-12 col-lg-6 col-xl-3">
						<!--Single Timeline Strat-->
						<a href="<?php echo base_url('pelayanan/igd'); ?>">
						<div class="single-timeline mb-50 d-flex align-items-center">
							<div class="timeline-frame">
								<center><img src="<?php echo base_url();?>assets_portal/img/icon/ic_igd.png"></center>
								<br>
								<div class="timeline-content">
									<div class="nama_t">INSTALASI GAWAT DARURAT</div>
									<p class="d_fasilitas">Tenaga Medis yang Sigap dan Kompeten</p>
								</div>
							</div>
							<br>
						</div>
						</a>
						<!--Single Timeline End-->
					</div>
				</div>
			<br>
			<hr>
			<br>
			</div>
		</div>
		<!--Feature Area End--><!--About Area Start-->
		<div class="about-area">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="about-wrapper black-bg1 pt-40 pb-110">
							<div class="row">

								<!--About Content Area Start-->
								<div class="col-sm-12 col-md-7 col-lg-7">
									<div class="about-content">
										<span>
											<font style="color: #005145; font-size: 20pt;">Lebih Praktis Dengan</font>
										</span>
										<div class="sub_title">PENDAFTARAN ONLINE</div>
										<p style="color: #717171; font-size: 15pt;">Lebih efektif, efisien, dan tidak lagi
											mengantri untuk mengambil nomor antrian</p>
										<div class="author-signeture">
											<a target="_blank" href="https://rsukarsahusadabatu.jatimprov.go.id/daftaronline" class="btn"
												style="background:  linear-gradient(39.43deg, #FF8906 2.49%, #FFB62D 96.01%);padding: 10px 25px; box-shadow: 0px 4px 4px #D5D5D5;">
												<font style="color: whitesmoke; font-size: 14pt; font-weight: 500;">Coba Sekarang</font>
											</a>
										</div>
									</div>
								</div>
								<!--About Content Area End-->
								<!--About Image Area Start-->
								<div class="col-md-5">
									<div class="about-img">
										<img class="bg_daftar" src="<?php echo base_url();?>assets_portal/img/bg/bg_pendaftaran.png" alt="">
									</div>
								</div>
								<!--About Image Area End-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<div class="about-area">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="about-wrapper black-bg1 pt-40 pb-110">
							<div class="row">

								<!--About Content Area Start-->
								<div class="col-sm-12 col-md-7 col-lg-7">
									<div class="about-content">
										<div class="sub_title">JKN MOBILE</div>
										<p style="color: #717171; font-size: 15pt;">Kini JKN MOBILE Telah Menyediakan Fitur Antrian Online , yang Dapat di Unduh di Playstore & AppStore</p>
										 <span>
											<font style="color: #005145; font-size: 20pt;">Link Download: </font>
										</span>
										<div class="author-signeture">
											<a target="_blank" href="https://play.google.com/store/apps/details?id=app.bpjs.mobile">
											    <img src="https://dramedia.id/wp-content/uploads/2019/10/google-play-badge-logo-png-transparent.png?w=640" width="200" height="60">
											</a>
											<a target="_blank" href="https://apps.apple.com/id/app/mobile-jkn/id1237601115">
											    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTD6YKWC0blFn47bFayX61mo3dk9xxrB2dncmdroqAp5-ESdnvx4OA5nSOCtVi8x4mcTg&usqp=CAU" width="200" height="60">
											</a>
										</div>
									</div>
								</div>
								<!--About Content Area End-->
								<!--About Image Area Start-->
								<div class="col-md-5">
									<div class="about-img">
										<img style="height:300px;width:300px" class="bg_daftar" src="https://apkvenue.com/app/wp-content/uploads/2020/02/mobile-jkn.png" alt="">
									</div>
								</div>
								<!--About Image Area End-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--Jadwal Dokter-->
		<!--<div class="service-area">-->
		<!--	<div class="container">-->
		<!--		<div class="row">-->
		<!--			<div class="col-12">-->
		<!--				<div class="view-all-history">-->
		<!--						<h2 style="color: #005145;text-align: center; letter-spacing: 0.05em; padding-top: 0px; padding-bottom: 20px;">JADWAL DOKTER</h2>-->
		<!--				</div>-->
		<!--			</div>-->
		<!--		</div>-->

		<!--		<div class="row align-items-center">-->

		<!--			<div class="col-12 col-lg-12">-->
		<!--				<div class="row galery">-->
		<!--					<div class="column col-12 col-lg-3">-->
		<!--						<img src="<?php echo base_url();?>file/polisiang/dr.dana.jpeg" style="width:100%" onclick="openModal1();currentSlide1(1)"-->
		<!--							class="hover-shadow cursor1">-->
		<!--					</div>-->
		<!--					<div class="column col-12 col-lg-3">-->
		<!--						<img src="<?php echo base_url();?>file/polisiang/dr.nugroho.jpeg" style="width:100%" onclick="openModal1();currentSlide1(2)"-->
		<!--							class="hover-shadow cursor1">-->
		<!--					</div>-->
		<!--					<div class="column col-12 col-lg-3">-->
		<!--						<img src="<?php echo base_url();?>file/polisiang/dr.revita.jpeg" style="width:100%" onclick="openModal1();currentSlide1(3)"-->
		<!--							class="hover-shadow cursor1">-->
		<!--					</div>-->
		<!--					<div class="column col-12 col-lg-3">-->
		<!--						<img src="<?php echo base_url();?>file/polisiang/dr.riyana.jpeg" style="width:100%" onclick="openModal1();currentSlide1(4)"-->
		<!--							class="hover-shadow cursor1">-->
		<!--					</div>-->
		<!--					<div class="column col-12 col-lg-3">-->
		<!--						<img src="<?php echo base_url();?>file/polisiang/dr.septi.jpeg" style="width:100%" onclick="openModal1();currentSlide1(5)"-->
		<!--							class="hover-shadow cursor1">-->
		<!--					</div>-->
		<!--				</div>-->
		<!--				<br>-->
		<!--				<br>-->
		<!--				<br>-->
		<!--				<hr>-->
		<!--			</div>-->
		<!--			<div id="myModal1" class="modal">-->
		<!--			<style>-->
		<!--			@media (min-width:1000px) {-->
		<!--			.close {-->
		<!--				color: white;-->
		<!--				position: absolute;-->
		<!--				top: 100px;-->
		<!--				right: 25px;-->
		<!--				font-size: 35px;-->
		<!--				font-weight: bold;-->
		<!--			}-->
		<!--			}-->
		<!--			</style>-->
		<!--				<span class="close cursor" onclick="closeModal1()">&times;</span>-->
		<!--					<div class="modal-content">-->
		<!--						<div class="mySlides13">-->
		<!--							<div class="numbertext">1 / 5</div>-->
		<!--								<img src="<?php echo base_url();?>file/polisiang/dr.dana.jpeg" style="width:100%;height: 100%;">-->
		<!--							</div>-->
		<!--						<div class="mySlides13">-->
		<!--							<div class="numbertext">2 / 5</div>-->
		<!--								<img src="<?php echo base_url();?>file/polisiang/dr.nugroho.jpeg" style="width:100%;height: 100%;">-->
		<!--							</div>-->
		<!--						<div class="mySlides13">-->
		<!--							<div class="numbertext">3 / 5</div>-->
		<!--								<img src="<?php echo base_url();?>file/polisiang/dr.revita.jpeg" style="width:100%;height: 100%;">-->
		<!--							</div>-->
		<!--						<div class="mySlides13">-->
		<!--							<div class="numbertext">4 / 5</div>-->
		<!--								<img src="<?php echo base_url();?>file/polisiang/dr.riyana.jpeg" style="width:100%;height: 100%;">-->
		<!--							</div>-->
		<!--						<div class="mySlides13">-->
		<!--							<div class="numbertext">5 / 5</div>-->
		<!--								<img src="<?php echo base_url();?>file/polisiang/dr.septi.jpeg" style="width:100%;height: 100%;">-->
		<!--							</div>-->
		<!--						<a class="prev" onclick="plusSlides1(-1)">&#10094;</a>-->
		<!--						<a class="next" onclick="plusSlides1(1)">&#10095;</a>-->
		<!--			</div>-->
		<!--		</div>-->

		<!--		<script>-->
		<!--			function openModal1() {-->
		<!--				document.getElementById("myModal1").style.display = "block";-->
		<!--			}-->

		<!--			function closeModal1() {-->
		<!--				document.getElementById("myModal1").style.display = "none";-->
		<!--			}-->

		<!--			var slideIndex = 1;-->
		<!--			showSlides1(slideIndex);-->

		<!--			function plusSlides1(n) {-->
		<!--				showSlides1(slideIndex += n);-->
		<!--			}-->

		<!--			function currentSlide1(n) {-->
		<!--				showSlides1(slideIndex = n);-->
		<!--			}-->

		<!--			function showSlides1(n) {-->
		<!--				var i;-->
		<!--				var slides = document.getElementsByClassName("mySlides13");-->
		<!--				var dots = document.getElementsByClassName("demo");-->
		<!--				var captionText = document.getElementById("caption");-->
		<!--				if (n > slides.length) {-->
		<!--					slideIndex = 1-->
		<!--				}-->
		<!--				if (n < 1) {-->
		<!--					slideIndex = slides.length-->
		<!--				}-->
		<!--				for (i = 0; i < slides.length; i++) {-->
		<!--					slides[i].style.display = "none";-->
		<!--				}-->
		<!--				for (i = 0; i < dots.length; i++) {-->
		<!--					dots[i].className = dots[i].className.replace(" active", "");-->
		<!--				}-->
		<!--				slides[slideIndex - 1].style.display = "block";-->
		<!--				dots[slideIndex - 1].className += " active";-->
		<!--				captionText.innerHTML = dots[slideIndex - 1].alt;-->
		<!--			}-->
		<!--		</script>-->
		<!--		</div>-->
		<!--	</div>-->

		<!--</div>-->
		<!--Jadwal Dokter-->

		<!--About Area End-->
		<style>
			
		</style>
		<!--Brand Area Start-->
		<div class="latest-blog-area bg-img-3 pt-120blog1 pb-85blog">
			<div class="container">

				<div class="row">
					<div class="col-md-12">
						<!--Section Title Start-->
						<div class="section-title text-center mb-701">
							<h2>
								<font style="color:#005145; letter-spacing: 0.05em">PORTAL BERITA</font>
							</h2>
						</div>
						<!--Section Title End-->
					</div>
				</div>
				<div class="row">
					<!--Single Blog Start-->
					<?php foreach ($berita->result() as $row) { ?>
					<div class="col-md-12 col-sm-12 col-lg-4">
						<div class="single-blog mb-30">
							<div class="responsive">
								<div class="gallery">
										<a class="link" href="<?php echo base_url('informasi/readmore/'.$row->id);?>">
										<?php if($row->kategori=="video"){?>
										<img src="https://assets.stickpng.com/images/580b57fcd9996e24bc43c545.png" alt="Mountains" width="100%">
										<?php }else{ ?>
											<img src="<?php echo base_url('file/berita/'.$row->image);?>" alt="Mountains" width="100%">
										<?php } ?>
									
									<div class="desc">
										<h3><b><?php echo substr($row->judul,0,50);?>...</b></h3>
										<h5 style="opacity: 0.7;"><?php echo date('l', strtotime($row->tanggal)).", ".date('d-m-Y', strtotime($row->tanggal));?></h5>
									</div>
									</a>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
					<!--Single Blog End-->
				</div>
				<center style="padding-top: 30px;">
					<a href="<?php echo base_url('informasi/berita'); ?>" class="btn"
						style="background:  linear-gradient(39.43deg, #FF8906 2.49%, #FFB62D 96.01%);padding: 10px 25px; box-shadow: 0px 4px 4px #737373a1">
						<font style="color: whitesmoke; font-size: 14pt; font-weight: 500;">Semua Berita</font>
					</a></center>
				<br><br>
			</div>
		</div>
		<!--Brand Area End-->

		<!--Service Area Start-->
		<div class="service-area pb-55">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="view-all-history">
								<h2 style="color: #005145;text-align: center; letter-spacing: 0.05em; padding-top: 80px; padding-bottom: 20px;">GALERI</h2>
						</div>
					</div>
				</div>

				<div class="row align-items-center">

					<div class="col-12 col-lg-12">
						<div class="row galery">
							<div class="column col-12 col-lg-3">
								<img src="<?php echo base_url();?>file/galeri/rskh-1.png" style="width:100%" onclick="openModal();currentSlide(1)"
									class="hover-shadow cursor">
							</div>
							<div class="column col-12 col-lg-3">
								<img src="<?php echo base_url();?>file/galeri/rskh-2.png" style="width:100%" onclick="openModal();currentSlide(2)"
									class="hover-shadow cursor">
							</div>
							<div class="column col-12 col-lg-3">
								<img src="<?php echo base_url();?>file/galeri/rskh-3.png" style="width:100%" onclick="openModal();currentSlide(3)"
									class="hover-shadow cursor">
							</div>
							<div class="column col-12 col-lg-3">
								<img src="<?php echo base_url();?>file/galeri/rskh-4.png" style="width:100%" onclick="openModal();currentSlide(4)"
									class="hover-shadow cursor">
							</div>
						</div>
						<hr>
					</div>
					<div id="myModal" class="modal">
						<span class="close cursor" onclick="closeModal()">&times;</span>
							<div class="modal-content">
								<div class="mySlides12">
									<div class="numbertext">1 / 4</div>
										<img src="<?php echo base_url();?>file/galeri/rskh-1.png" style="width:100%;height: 100%;">
									</div>
								<div class="mySlides12">
									<div class="numbertext">2 / 4</div>
										<img src="<?php echo base_url();?>file/galeri/rskh-2.png" style="width:100%;height: 100%;">
									</div>
								<div class="mySlides12">
									<div class="numbertext">3 / 4</div>
										<img src="<?php echo base_url();?>file/galeri/rskh-3.png" style="width:100%;height: 100%;">
									</div>
								<div class="mySlides12">
									<div class="numbertext">4 / 4</div>
										<img src="<?php echo base_url();?>file/galeri/rskh-4.png" style="width:100%;height: 100%;">
									</div>
								<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
								<a class="next" onclick="plusSlides(1)">&#10095;</a>
					</div>
				</div>

				<script>
					function openModal() {
						document.getElementById("myModal").style.display = "block";
					}

					function closeModal() {
						document.getElementById("myModal").style.display = "none";
					}

					var slideIndex = 1;
					showSlides(slideIndex);

					function plusSlides(n) {
						showSlides(slideIndex += n);
					}

					function currentSlide(n) {
						showSlides(slideIndex = n);
					}

					function showSlides(n) {
						var i;
						var slides = document.getElementsByClassName("mySlides12");
						var dots = document.getElementsByClassName("demo");
						var captionText = document.getElementById("caption");
						if (n > slides.length) {
							slideIndex = 1
						}
						if (n < 1) {
							slideIndex = slides.length
						}
						for (i = 0; i < slides.length; i++) {
							slides[i].style.display = "none";
						}
						for (i = 0; i < dots.length; i++) {
							dots[i].className = dots[i].className.replace(" active", "");
						}
						slides[slideIndex - 1].style.display = "block";
						dots[slideIndex - 1].className += " active";
						captionText.innerHTML = dots[slideIndex - 1].alt;
					}
				</script>
				</div>
			</div>

		</div>

		<div class="latest-blog-area1 bg-img-4 pt-120pengaduan pb-85blog">
			<div class="container">

				<div class="row">
					<div class="col-md-12">
						<!--Section Title Start-->
						<div class="section-title text-center mb-30" style="padding-top: 35px">
							<h1>
								<font style="color: #009982; font-size: 23pt; ">LAYANAN PENGADUAN</font>
							</h1>
						</div>
						<div class="section-title text-center mb-301">
							<div class="col-md-12 col-lg-12">
								<p style="color: #4D4D4D; font-size: 14.5pt; font-weight: 400; letter-spacing: 0.05em;">Laporkan segala bentuk pengaduan Anda<br>tentang kami disini</p><br>
							</div>
							<center><a target="_blank" href="https://rsukarsahusadabatu.jatimprov.go.id/ecomplaint/dashboard.php" class="btn btn-sm" style="background:  linear-gradient(39.43deg, #FF8906 2.49%, #FFB62D 96.01%); padding: 8px 20px;  box-shadow: 0px 4px 4px #D5D5D5;">
									<font style="color: whitesmoke; font-size: 14pt; font-weight: 500;">E-Complaint</font></a>
							</center>
						</div>
						<!--Section Title End-->
					</div>
				</div>
				<br><br>
			</div>
		</div>
		<br><br>

		<div class="latest-blog-area1 pt-120pengaduan1 pb-25blog">
			<div class="container">

				<div class="row">
					<div class="col-md-12">
						<!--Section Title Start-->
						<div class="section-title text-center mb-30">
							<h1>
								<font style="color: #005145;text-align: center; letter-spacing: 0.05em;">PETA LOKASI</font>
							</h1>
						</div>
						<div class="section-title text-center mb-301">
							<div class="col-md-12 col-lg-12">
							</div>
							<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d988.0542946724078!2d112.52272479847942!3d-7.87232930202862!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78873338da2c49%3A0x659610908a6d8beb!2sRSU%20Karsa%20Husada%20Batu!5e0!3m2!1sid!2sid!4v1577409408477!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					</center>
						</div>

						<!--Section Title End-->
					</div>
				</div>
				<br><br>
			</div>
		</div>
		
		<div class="service-area pb-80">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="view-all-history">
								<h2 style="color: #005145;text-align: center; letter-spacing: 0.05em; padding-top: 80px; padding-bottom: 20px;">TAUTAN LAINNYA</h2>
						</div>
					</div>
				</div>

				<div class="row align-items-center">

					<div class="col-12 col-lg-12">
						<div class="row galery">
							<div class="column col-12 col-lg-2">
								<a target="_blank" href="https://faskes.bpjs-kesehatan.go.id/aplicares/#/app/dashboard"><img src="<?php echo base_url();?>assets_portal/img/tautan/BPJS.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
							<div class="column col-12 col-lg-2">
							<a target="_blank" href="https://www.kpk.go.id/id/"><img src="<?php echo base_url();?>assets_portal/img/tautan/KPK.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
							<div class="column col-12 col-lg-2">
							<a target="_blank" href="http://lpse.batukota.go.id/eproc4"><img src="<?php echo base_url();?>assets_portal/img/tautan/LPSE_BATU.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
							<div class="column col-12 col-lg-2">
							<a target="_blank" href="https://lpse.jatimprov.go.id/eproc4"><img src="<?php echo base_url();?>assets_portal/img/tautan/LPSE_JATIM.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
							<div class="column col-12 col-lg-2">
							<a target="_blank" href="https://www.perpusnas.go.id/index.php?lang=id"><img src="<?php echo base_url();?>assets_portal/img/tautan/PERPUSTAKAAN.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
							<div class="column col-12 col-lg-2">
							<a target="_blank" href="<?php echo base_url('etik_penelitian')?>"><img src="<?php echo base_url();?>assets_portal/img/tautan/SIM-EPK.png" style="width:100%" class="hover-shadow cursor"></a>
							</div>
						</div>
						<hr>
					</div>
				</div>
			</div>

		</div>


		<!--Service Area End-->
		<!--Footer Area Start-->
	<?php  $this->load->view('portal/template/footer'); ?>
		<!--Footer Area End-->
	</div>
<?php $this->load->view('portal/template/footer_js'); ?>
</body>

</html>