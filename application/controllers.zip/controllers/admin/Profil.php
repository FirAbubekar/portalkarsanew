<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
	}

	public function sejarah()
	{
		$data['title'] = "Admin | RSU Karsa Husada";

        $datas['username'] = $this->session->userdata('username');

		$data['a_dashboard']	= '';
		$data['a_profil'] 		= 'active';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= 'active';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$this->db->order_by('tahun','asc');
		$data['sejarah'] = $this->db->get('t_sejarah');

		$this->load->view('admin/sejarah/tabel_sejarah',$data);
	}

	public function save_sejarah(){
		$tahun 		= $this->input->post('tahun');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/sejarah';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
			
		$gambar = substr($_FILES['gambar']['name'],-4);
		$gambar = strtolower(str_replace(' ','_',$tahun."".$gambar));
		$config['file_name'] 			= strtolower($tahun);
			
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload('gambar')){
			$error = array('error' => $this->upload->display_errors());
		}else{
			$data = array('upload_data' => $this->upload->data());
		}

		$data = array('tahun'		=> $tahun,
					  'deskripsi'	=> $deskripsi,
					  'gambar'		=> $gambar,
					  'status'		=> $status);
		$this->db->insert('t_sejarah',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Sejarah, Pada Tahun = <b>".$tahun."</b>...");

		redirect('admin/profil/sejarah');
	}

	public function edit_sejarah($id){
		
		$this->db->where('id',$id);
		$dbsejarah = $this->db->get('t_sejarah')->row();

		$tahun 		= $this->input->post('tahun');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/sejarah';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
			
		if($_FILES['gambar']['name']==null){
			if($dbsejarah->gambar!=null){
				$gambar = $dbsejarah->gambar;
			}
		}
		else{
			unlink('file/sejarah/'.$dbsejarah->gambar);
			$gambar = substr($_FILES['gambar']['name'],-4);
			$gambar = strtolower(str_replace(' ','_',$tahun."".$gambar));
			$config['file_name'] 			= strtolower($tahun);
			$this->load->library('upload', $config);

			if ( !$this->upload->do_upload('gambar')){
				$error = array('error' => $this->upload->display_errors());
			}else{
				$data = array('upload_data' => $this->upload->data());
			}
		}

		$data = array('tahun'		=> $tahun,
					  'deskripsi'	=> $deskripsi,
					  'gambar'		=> $gambar,
					  'status'		=> $status);

		$this->db->where('id',$id);
		$this->db->update('t_sejarah',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Sejarah, Pada Tahun  = <b>".$tahun."</b>...");

		redirect('admin/profil/sejarah');
	}

	public function delete_sejarah($id){

		$this->db->where('id',$id);
		$dbsejarah = $this->db->get('t_sejarah')->row();

		if($dbsejarah->gambar!=null){
			unlink('file/sejarah/'.$dbsejarah->gambar);
		}
		
		$this->db->where('id',$id);
		$this->db->delete('t_sejarah');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Sejarah ");

		redirect('admin/profil/sejarah');
	}

	public function visimisi()
	{
		$data['title'] = "Admin | RSU Karsa Husada";

        $datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= 'active';
		$data['a_visi'] 		= 'active';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$this->db->order_by('');
		$data['profil'] = $this->db->get('t_profil');

		$this->load->view('admin/visimisi/tabel_visimisi',$data);
	}

	public function save_visimisi(){
		$judul 		= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$data = array('judul'		=> $judul,
					  'deskripsi'	=> $deskripsi,
					  'status'		=> $status);
		$this->db->insert('t_profil',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Visi Misi, Dengan Judul = <b>".$judul."</b>...");

		redirect('admin/profil/visimisi');
	}

	public function edit_visimisi($id){
		$judul 		= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$data = array('judul'		=> $judul,
					  'deskripsi'	=> $deskripsi,
					  'status'		=> $status);
		$this->db->where('id',$id);
		$this->db->update('t_profil',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Visi Misi, Dengan Judul  = <b>".$judul."</b>...");

		redirect('admin/profil/visimisi');
	}

	public function delete_visimisi($id){
		
		$this->db->where('id',$id);
		$this->db->delete('t_profil');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Visi Misi ");

		redirect('admin/profil/visimisi');
	}
	
		public function tugasfungsi()
	{
		$data['title'] = "Admin | RSU Karsa Husada";

        $datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= 'active';
		$data['a_visi'] 		= 'active';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$this->db->order_by('');
		$data['tugasfungsi'] = $this->db->get('t_tugasfungsi');

		$this->load->view('admin/tugasfungsi/tabel_tugasfungsi',$data);
	}

	public function save_tugasfungsi(){
		date_default_timezone_set("Asia/Jakarta");
		$id	= "TF" . date('YmdHis');
		$judul 		= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$data = array('id_tugasfungsi'=> $id,
					  'subjudul'	=> $judul,
					  'deskripsi'	=> $deskripsi,
					  'status'		=> $status);
		$this->db->insert('t_tugasfungsi',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Visi Misi, Dengan Judul = <b>".$judul."</b>...");

		redirect('admin/profil/tugasfungsi');
	}

	public function edit_tugasfungsi($id){
		$judul 		= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$data = array('subjudul'		=> $judul,
					  'deskripsi'	=> $deskripsi,
					  'status'		=> $status);
		$this->db->where('id_tugasfungsi',$id);
		$this->db->update('t_tugasfungsi',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Visi Misi, Dengan Judul  = <b>".$judul."</b>...");

		redirect('admin/profil/tugasfungsi');
	}

	public function delete_tugasfungsi($id){
		
		$this->db->where('id_tugasfungsi',$id);
		$this->db->delete('t_tugasfungsi');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Visi Misi ");

		redirect('admin/profil/tugasfungsi');
	}

	public function sdm()
	{
		$data['title'] = "Admin | RSU Karsa Husada";

        $datas['username'] = $this->session->userdata('username');

		$data['a_dashboard']	= '';
		$data['a_profil'] 		= 'active';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= 'active';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$data['sdm'] = $this->db->get('t_sdm');

		$this->load->view('admin/sdm/tabel_sdm',$data);
	}

		public function save_sdm(){
		$jenis 		= $this->input->post('jenis');
		$jumlah 	= $this->input->post('jumlah');
		$status 	= $this->input->post('status');
		$pns 	 	= $this->input->post('pns');
		$blud	 	= $this->input->post('blud');
		$mou	 	= $this->input->post('mou');
		$kontrak 	= $this->input->post('kontrak');
		$s2 		= $this->input->post('s2');
		$s1		 	= $this->input->post('s1');
		$d4		 	= $this->input->post('d4');
		$d3		 	= $this->input->post('d3');
		$d2		 	= $this->input->post('d2');
		$d1		 	= $this->input->post('d1');
		$sma	 	= $this->input->post('sma');

		$data = array('jenis'		=> $jenis,
					  'jumlah'		=> $jumlah,
					  'pns'			=> $pns,
					  'blud'		=> $blud,
					  'mou'			=> $mou,
					  'kontrak'		=> $kontrak,
					  's2'			=> $s2,
					  's1'			=> $s1,
					  'd4'			=> $d4,
					  'd3'			=> $d3,
					  'd2'			=> $d2,
					  'd1'			=> $d1,
					  'sma'			=> $sma,
					  'status'		=> $status);
		$this->db->insert('t_sdm',$data);

		redirect('admin/profil/sdm');
	}

	public function edit_sdm($id){
		$jenis 		= $this->input->post('jenis');
		$jumlah 	= $this->input->post('jumlah');
		$status 	= $this->input->post('status');
		$pns 	 	= $this->input->post('pns');
		$blud	 	= $this->input->post('blud');
		$mou	 	= $this->input->post('mou');
		$kontrak 	= $this->input->post('kontrak');
		$s2 		= $this->input->post('s2');
		$s1		 	= $this->input->post('s1');
		$d4		 	= $this->input->post('d4');
		$d3		 	= $this->input->post('d3');
		$d2		 	= $this->input->post('d2');
		$d1		 	= $this->input->post('d1');
		$sma	 	= $this->input->post('sma');

		$data = array('jenis'		=> $jenis,
					  'jumlah'		=> $jumlah,
					  'pns'			=> $pns,
					  'blud'		=> $blud,
					  'mou'			=> $mou,
					  'kontrak'		=> $kontrak,
					  's2'			=> $s2,
					  's1'			=> $s1,
					  'd4'			=> $d4,
					  'd3'			=> $d3,
					  'd2'			=> $d2,
					  'd1'			=> $d1,
					  'sma'			=> $sma,
					  'status'		=> $status);
		$this->db->where('id',$id);
		$this->db->update('t_sdm',$data);

		redirect('admin/profil/sdm');
	}

	public function delete_sdm($id){
		
		$this->db->where('id',$id);
		$this->db->delete('t_sdm');

		redirect('admin/profil/sdm');
	}
	
	public function struktur()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
		
        $datas['username'] = $this->session->userdata('username');

		$data['a_dashboard']	= '';
		$data['a_profil'] 		= 'active';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= 'active';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$this->db->order_by('urutan','asc');
		$data['struktur'] = $this->db->get('detail_struktur');

		$this->load->view('admin/struktur/tabel_struktur',$data);
    }

    public function save_struktur(){
		$nama 		= $this->input->post('nama');
		$jabatan 	= $this->input->post('jabatan');
		$urutan 	= $this->input->post('urutan');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/struktur';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
			
		$gambar = substr($_FILES['gambar']['name'],-4);
		$namas = str_replace('.', '_', $nama);
		$gambar = strtolower(str_replace(' ','_',$namas	."".$gambar));
		$config['file_name'] 			= strtolower($namas);
			
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload('gambar')){
			$error = array('error' => $this->upload->display_errors());
		}else{
			$data = array('upload_data' => $this->upload->data());
		}

		$data = array('nama'	=> $nama,
					  'jabatan'	=> $jabatan,
					  'urutan'	=> $urutan,
					  'gambar'	=> $gambar,
					  'status'	=> $status);
		$this->db->insert('detail_struktur',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Struktur, Dengan Nama = <b>".$nama."</b>...");

		redirect('admin/profil/struktur');
	}

	public function edit_struktur($id){

		$this->db->where('id',$id);
		$dbstruktur = $this->db->get('detail_struktur')->row();

		$nama 		= $this->input->post('nama');
		$jabatan 	= $this->input->post('jabatan');
		$urutan 	= $this->input->post('urutan');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/struktur';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
			
		if($_FILES['gambar']['name']==null){
			if($dbstruktur->gambar!=null){
				$gambar = $dbstruktur->gambar;
			}
		}
		else{
			unlink('file/struktur/'.$dbstruktur->gambar);
			$gambar = substr($_FILES['gambar']['name'],-4);
			$namas = str_replace('.', '_', $nama);
			$gambar = strtolower(str_replace(' ','_',$namas."".$gambar));
			$config['file_name'] 			= strtolower($namas);
			$this->load->library('upload', $config);

			if ( !$this->upload->do_upload('gambar')){
				$error = array('error' => $this->upload->display_errors());
			}else{
				$data = array('upload_data' => $this->upload->data());
			}
		}

		$data = array('nama'	=> $nama,
					  'jabatan'	=> $jabatan,
					  'urutan'	=> $urutan,
					  'gambar'	=> $gambar,
					  'status'	=> $status);
		$this->db->where('id',$id);
		$this->db->update('detail_struktur',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Struktur, Dengan Nama  = <b>".$nama."</b>...");

		redirect('admin/profil/struktur');
	}

	public function delete_struktur($id){

		$this->db->where('id',$id);
		$dbstruktur = $this->db->get('detail_struktur')->row();

		if($dbstruktur->gambar!=null){
			unlink('file/struktur/'.$dbstruktur->gambar);
		}
		
		$this->db->where('id',$id);
		$this->db->delete('detail_struktur');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Struktur ");

		redirect('admin/profil/struktur');
	}
    
}
