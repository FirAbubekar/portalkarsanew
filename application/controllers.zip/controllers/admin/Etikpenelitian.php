<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Etikpenelitian extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
	}

	public function index()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
		
		$datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$akun = $this->db->get('t_etikpenelitian');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_etikpenelitian');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_etikpenelitian');
		$data['nonaktif'] = $akun->num_rows();

		$data['etikpenelitian'] = $this->db->get('t_etikpenelitian');

		$this->load->view('admin/etik/tabel_etikpenelitian',$data);
	}

	public function save(){
		
		$username = $this->session->userdata('username') ;
		$kdDokumen 	= "EP".date('YmdHis');
		$judul   	= $this->input->post('judul');
		$tanggal 	= $this->input->post('tanggal');
		$link 		= $this->input->post('link');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$data		= array(
							'kdDokumen'=>$kdDokumen,
							'judulDokumen'=>$judul,
							'deskripsiDokumen'=>$deskripsi,
							'linkDownload'=>$link,
							'tanggalUpload'=>$tanggal,
							'createdDate'=>date('Y-m-d H:i:s'),
							'userCreated'=>$username,
							'status'=>$status);

		$this->db->insert('t_etikpenelitian',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Etik Penelitian, Dengan Nama File  = <b>".$judul."</b>...");

		redirect('admin/etikpenelitian');
   	}

   	public function edit($id){

		$this->db->where('id',$id);
		$dbppid		= $this->db->get('t_ppid')->row();

		$judul   	= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/ppid';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 4000;
		$config['max_height']           = 4000;

		if($_FILES['gambar']['name']==null){
			if($dbppid->gambar!=null){
				$gambar = $dbppid->gambar;
			}
		}
		else{
		unlink('file/ppid/'.$dbppid->gambar);
		$gambar = substr($_FILES['gambar']['name'],-4);
		$gambar = strtolower(str_replace(' ','_',$judul."".$gambar));
		$config['file_name'] 			= strtolower($judul);
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload('gambar')){
			$error = array('error' => $this->upload->display_errors());
		}else{
			
			$data = array('upload_data' => $this->upload->data());
		}
		}
	
		$data		= array('judul'			=>$judul,
							'deskripsi'		=>$deskripsi,
							'gambar'		=>$gambar,
							'status'		=>$status);
	

		$this->db->where('id',$id);
		$this->db->update('t_ppid',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Perpustakaan, Dengan Nama File  = <b>".$nama_file."</b>...");

		redirect('admin/ppid');
	}

	public function form(){
		$data['title'] = "Admin | RSU Karsa Husada";
		
		$datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= 'active';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$akun = $this->db->get('t_permohonanppid');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_permohonanppid');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_permohonanppid');
		$data['nonaktif'] = $akun->num_rows();

		$data['ppid'] = $this->db->get('t_permohonanppid');
		$this->load->view('admin/ppid/tabel_formppid',$data);
	}

	public function getdetail(){
		$kdpermohonan = $this->input->post('kdpermohonan');

		$this->db->where('kdPermohonan',$kdpermohonan);
		$getdetail = $this->db->get('t_permohonanppid')->row();

		echo json_encode($getdetail);
	}

  	public function delete($id){
		$this->db->where('kdDokumen',$id);
		$this->db->delete('t_etikpenelitian');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Perpustakaan");

		redirect('admin/etikpenelitian');
   	}
    
}
