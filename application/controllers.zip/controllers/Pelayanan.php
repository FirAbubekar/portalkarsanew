<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelayanan extends CI_Controller {

	public function unggulan()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= 'active';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'unggulan';
		
		$title					= 'LAYANAN UNGGULAN';
		$data['title']			= $title;

		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

		$this->load->view('portal/pelayanan',$data);
    }
    public function igd()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= 'active';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'igd';
		$title					= 'INSTALASI GAWAT DARURAT';
		$data['title']			= $title;

		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

	$this->load->view('portal/pelayanan', $data);
	}
	
		public function rawat_jalan()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= 'active';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'rajal';

		$title					= 'INSTALASI RAWAT JALAN';
		$data['title']			= $title;

		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

		$this->load->view('portal/pelayanan_rawatjalan',$data);
    }
    public function rawat_inap()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= 'active';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'ranap';

		$title					= 'INSTALASI RAWAT INAP';
		$data['title']			= $title;

		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

		$this->load->view('portal/pelayanan_rawatinap', $data);
	}
	
	public function detail_rawatjalan($tipe)
	{
		$n_tipe = strtoupper(str_replace('_',' ',$tipe));
		$data['tipe'] = $n_tipe;
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= 'active';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'rawatjalan';

		$title					= 'INSTALASI RAWAT JALAN ';
		$data['title']			= $title;
		
		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$this->db->where('sub_judul',$n_tipe);
		$data['unggulan'] = $this->db->get('t_pelayanan');
		
		$this->load->view('portal/pelayanan', $data);
	}

	public function detail_rawatinap($tipe)
	{
		$n_tipe = strtoupper(str_replace('_',' ',$tipe));
		$data['tipe'] = $n_tipe;
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= 'active';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'rawatinap';

		$title					= 'INSTALASI RAWAT INAP ';
		$data['title']			= $title;
		
		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$this->db->where('sub_judul',$n_tipe);
		$data['unggulan'] = $this->db->get('t_pelayanan');
		
		$this->load->view('portal/pelayanan', $data);
	}
	
	public function rawat_jalan1()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= 'active';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'rajal';

		$title					= 'INSTALASI RAWAT JALAN';
		$data['title']			= $title;

		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

		$this->load->view('portal/pelayanan',$data);
    }
    public function rawat_inap1()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= 'active';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'ranap';

		$title					= 'INSTALASI RAWAT INAP';
		$data['title']			= $title;

		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$data['unggulan'] = $this->db->get('t_pelayanan');

		$this->load->view('portal/pelayanan', $data);
	}
	public function penunjang()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= 'active';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->load->view('portal/pelayanan_penunjang', $data);
	}

	public function medis($tipe)
	{
		$n_tipe = strtoupper(str_replace('_',' ',$tipe));
		$data['tipe'] = $n_tipe;
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= 'active';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'medis';

		$title					= 'PENUNJANG MEDIS ';
		$data['title']			= $title;
		
		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$this->db->where('sub_judul',$n_tipe);
		$data['unggulan'] = $this->db->get('t_pelayanan');
		
		$this->load->view('portal/pelayanan', $data);
	}

	public function nonmedis($tipe)
	{
		$n_tipe = strtoupper(str_replace('_',' ',$tipe));
		$data['tipe'] = $n_tipe;
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= 'active';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['location']		= 'medis';

		$title					= 'PENUNJANG NON MEDIS ';
		$data['title']			= $title;
		
		$this->db->where('status','1');
		$this->db->where('judul',$title);
		$this->db->where('sub_judul',$n_tipe);
		$data['unggulan']= $this->db->get('t_pelayanan');
		
		$this->load->view('portal/pelayanan', $data);
	}

	public function tarif()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= 'active';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->db->select('jenis_pelayanan,tarif');
		$this->db->where('nama','Instalasi Gawat Darurat');
		$data['igd'] = $this->db->get('t_tarif');

		$this->db->select('jenis_pelayanan, tarif_rajal, executive');
		$this->db->where('nama','Rawat Jalan');
		$data['rajal'] = $this->db->get('t_tarif');

		$this->db->select('jenis_pelayanan, kelas1, kelas2, kelas3, kelas_utama');
		$this->db->where('nama','Rawat Inap');
		$data['ranap'] = $this->db->get('t_tarif');

		$this->load->view('portal/tarif',$data);
	}
	public function alur()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= 'active';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->db->where('status','1');
		$this->db->group_by('alur');
		$data['alur'] = $this->db->get('t_alur');

		$this->db->where('status','1');
		$data['t_alur'] = $this->db->get('t_alur');

		$this->load->view('portal/alur',$data);
	}
	public function jadwal_dokter()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= '';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= 'active';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= 'active';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['jadwal'] = $this->db->get('t_jadwal_dokter');
		$this->load->view('portal/jadwal_dokter',$data);
	}
}
