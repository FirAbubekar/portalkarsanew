<!doctype html>
<html class="no-js" lang="en">

<head>
	<?php $this->load->view('portal/template/header_css'); ?>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets_portal/css/pendukung/pelayanan.css">

</head>

<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

	<div class="wrapper">
		<!--Header Area Start-->
		<?php $this->load->view('portal/template/menu'); ?>
		<!--Header Area End-->
		<!--Brand Area Start-->
		<div class="latest-blog-area pt-120blog">
			<img src="<?php echo base_url();?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
		</div>
		<div class="visi">
			<div class="title1 pt-120blog">
				<?php echo $title; ?>
				<hr>
			</div>
		</div>
		<div class="fun-factor-area bg-img pt-35">
			<?php foreach ($unggulan->result() as $row) { ?>
			<div class="container1">
				<div class="ruangan">
					<h3><?php echo $row->sub_judul;?></h3>
				</div>
				<div class="row justify-content-between">
					<!--Single Funfactor Area Start-->
                    <?php 
                    $this->db->where('id_pelayanan',$row->id);
                    $gmbr = $this->db->get('detail_pelayanan');
                    foreach ($gmbr->result() as $img) { ?>
						<?php 
						if($row->sub_judul!=null){
							$judul =  $row->sub_judul;
						}
						else{
							$judul =  $row->judul;
						}
						$judul = strtolower(preg_replace("/[^a-zA-Z]/","_",$judul));
						?>
					<div class="img-pel col-lg-6 col-md-12 col-sm-12">
						<img style="width: 100%;height:300px;" src="<?php echo base_url('file/pelayanan/'.$judul.'/'.$img->gambar);?>"
							alt="">
					</div>
                    <?php } ?>
				</div>
				<div class="describe">
					<div class="jam">Jam Pelayanan : </div>
					<div class="d_jam">
					<?php echo $row->waktu_pelayanan; ?>
					</div>
					<div class="describe">
						<div class="jam">Keterangan : </div>
						<div class="d_ket">
						<?php echo $row->keterangan; ?>	
						</div>
					</div>
				</div>
				<hr size="2">
			</div>
            <?php } ?>
		</div>

	</div>

	<!--Brand Area End-->

	<?php $this->load->view('portal/template/footer'); ?>
	<!--Footer Area End-->
	</div>

	<!--Jquery 1.12.4-->
	<?php $this->load->view('portal/template/footer_js'); ?>
</body>

</html>