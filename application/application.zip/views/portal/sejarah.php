<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php $this->load->view('portal/template/header_css'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <style>
        .disk {
            background-color: lightgrey;
            width: 300px;
            border: 15px solid green;
            padding: 50px;
            margin: 20px;
        }

        div.gallery {
            border: 0px solid #ccc;
        }

        div.gallery:hover {
            border: px solid #777;
        }

        div.gallery img {
            width: 100%;
            height: auto;
        }

        div.desc {
            padding: 15px;
            text-align: left;
            background: whitesmoke;
        }

        * {
            box-sizing: border-box;
        }

        .responsive {
            padding: 0 6px;
            float: left;
            width: 70%;
            opacity: 0.5;
            margin-bottom: 70px;
        }

        .kotak {
            width: 22px;
            height: 22px;
            background: #FF8B00;
            -moz-border-radius: 50px;
            -webkit-border-radius: 50px;
            border-radius: 50px;
            opacity: 0.5;
        }

        .single-blog:hover .responsive {
            padding: 0 6px;
            float: left;
            width: 100%;
            opacity: 1;
            margin-bottom: 70px;
        }

        .single-blog:hover .kotak {
            padding: 0 6px;
            float: left;
            opacity: 1;
            margin-bottom: 70px;
        }

        .line {
            width: 4417px;
            height: 0px;

            border: 2px solid #5FD4C3;
            transform: rotate(90deg);
        }

        @media only screen and (max-width: 700px) {
            .responsive {
                padding: 0 6px;
                float: left;
                width: 70%;
                opacity: 0.5;
                margin-bottom: 70px;
            }

            .kotak {
                width: 22px;
                height: 22px;
                background: #FF8B00;
                -moz-border-radius: 50px;
                -webkit-border-radius: 50px;
                border-radius: 50px;
                opacity: 0.5;
            }

            .single-blog:hover .responsive {
                padding: 0 6px;
                float: left;
                width: 70%;
                opacity: 1;
                margin-bottom: 70px;
            }

            .single-blog:hover .kotak {
                padding: 0 6px;
                float: left;
                opacity: 1;
                margin-bottom: 70px;
            }
        }

        @media only screen and (max-width: 500px) {
            .responsive {
                padding: 0 6px;
                float: left;
                width: 70%;
                opacity: 0.5;
                margin-bottom: 70px;
            }

            .kotak {
                width: 22px;
                height: 22px;
                background: #FF8B00;
                -moz-border-radius: 50px;
                -webkit-border-radius: 50px;
                border-radius: 50px;
                opacity: 0.5;
            }

            .single-blog:hover .responsive {
                padding: 0 6px;
                float: left;
                width: 70%;
                opacity: 1;
                margin-bottom: 70px;
            }

            .single-blog:hover .kotak {
                padding: 0 6px;
                float: left;
                opacity: 1;
                margin-bottom: 70px;
            }
        }

        .clearfix:after {
            content: "";
            display: table;
            clear: both;
        }

        .title1 {
            padding-left: 10%;
            padding-bottom: 50px;
            color: #105b50;
        }

        .row>.column {
            padding: 20px 8px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .column {
            float: left;
            width: 25%;
        }

        /* The Modal (background) */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: black;
        }

        /* Modal Content */
        .modal-content {
            position: relative;
            background-color: #fefefe;
            margin: auto;
            padding: 0;
            width: 40%;
        }

        /* The Close Button */
        .close {
            color: white;
            position: absolute;
            top: 10px;
            right: 25px;
            font-size: 35px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #999;
            text-decoration: none;
            cursor: pointer;
        }

        .mySlides {
            display: none;
        }

        .cursor {
            cursor: pointer;
        }

        /* Next & previous buttons */
        .prev,
        .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -50px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
            -webkit-user-select: none;
        }

        /* Position the "next button" to the right */
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover,
        .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Number text (1/3 etc) */
        .numbertext {
            color: #f2f2f2;
            font-size: 12px;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        img {
            margin-bottom: -4px;
        }

        .caption-container {
            text-align: center;
            background-color: black;
            padding: 2px 16px;
            color: white;
        }

        .demo {
            opacity: 0.6;
        }

        .active,
        .demo:hover {
            opacity: 1;
        }

        img.hover-shadow {
            transition: 0.3s;
        }

        .hover-shadow:hover {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .container {
            position: relative;
            font-family: Arial;
        }

        .text-block {
            position: absolute;
            width: 30%;
            height: auto;
            left: 140px;
            top: 40%;
            padding-left: 20PX;
            padding-top: 20px;
            padding-bottom: 20px;
            background: rgba(255, 255, 255, 0.8);
            padding-right: 20px;
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

    <div class="wrapper">
        <!--Header Area Start-->
        <?php $this->load->view('portal/template/menu'); ?>
        <!--Header Area End-->
        <!--Slider Area Start-->


        <!--Brand Area Start-->
        <div class="latest-blog-area pt-120blog">
            <img src="<?php echo base_url();?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
        </div>
        <div class="title1 pt-120blog pb-85blog">
            <h1>SEJARAH RUMAH SAKIT KARSA HUSADA</h1>
        </div>
        <div class="latest-blog-area bg-img-1 pb-85blog">
            <div class="container">
                <?php foreach ($sejarah->result() as $row) { ?>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-lg-12">
                        <div class="single-blog mb-30">
                            <div class="col-md-2 col-sm-2 col-lg-2">
                                <div class="kotak">
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-10 col-lg-10">
                                <div class="responsive">
                                    <div class="gallery">
                                        <h4 class="title"><?php echo $row->tahun; ?></h4>
                                        <?php if($row->gambar!=null){ ?>
                                        <img src="<?php echo base_url('file/sejarah/'.$row->gambar);?>" alt="" width="100%">
                                        <?php } ?>
                                        <div class="desc"><?php echo $row->deskripsi; ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>


    </div>

    <!--Brand Area End-->

    <?php  $this->load->view('portal/template/footer'); ?>
    <!--Footer Area End-->
    </div>

    <!--Jquery 1.12.4-->
    <script src="<?php echo base_url();?>assets_portal/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets_portal/js/vendor/jquery-1.12.4.min.js"></script>
    <!--Waypoints-->
    <script src="<?php echo base_url();?>assets_portal/js/waypoints.min.js"></script>
    <!--Counterup-->
    <script src="<?php echo base_url();?>assets_portal/js/jquery.counterup.min.js"></script>
    <!--Carousel-->
    <script src="<?php echo base_url();?>assets_portal/js/owl.carousel.min.js"></script>
    <!--Meanmenu-->
    <script src="<?php echo base_url();?>assets_portal/js/jquery.meanmenu.min.js"></script>
    <!--Instafeed-->
    <script src="<?php echo base_url();?>assets_portal/js/instafeed.min.js"></script>
    <!--Datepicker-->
    <script src="<?php echo base_url();?>assets_portal/js/jquery.datepicker.min.js"></script>
    <!--Calendar-->
    <script src="<?php echo base_url();?>assets_portal/js/zabuto-calendar.min.js"></script>
    <!--ScrollUp-->
    <script src="<?php echo base_url();?>assets_portal/js/jquery.scrollUp.min.js"></script>
    <!--Wow-->
    <script src="<?php echo base_url();?>assets_portal/js/wow.min.js"></script>
    <!--Venobox-->
    <script src="<?php echo base_url();?>assets_portal/js/venobox.min.js"></script>
    <!--Popper-->
    <script src="<?php echo base_url();?>assets_portal/js/popper.min.js"></script>
    <!--Bootstrap-->
    <script src="<?php echo base_url();?>assets_portal/js/bootstrap.min.js"></script>
    <!--Plugins-->
    <script src="<?php echo base_url();?>assets_portal/js/plugins.js"></script>
    <!--Main Js-->
    <script src="<?php echo base_url();?>assets_portal/js/main.js"></script>
</body>

</html>