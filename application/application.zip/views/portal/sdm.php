<!doctype html>
<html class="no-js" lang="en">
<head>
	<?php $this->load->view('portal/template/header_css'); ?>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets_portal/css/pendukung/sdm.css">
</head>
<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div class="wrapper">
	<!--Header Area Start-->
	<?php $this->load->view('portal/template/menu'); ?>
	<!--Header Area End-->
	<!--Slider Area Start-->
	
	
	<!--Brand Area Start-->
	<div class="latest-blog-area pt-120blog">
		<img src="<?php echo base_url() ?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
	 	</div>
	<div class="visi">
		<div class="title1 pt-120blog">
			<h1>Sumber Daya Manusia</h1>
		</div>
		<div class="fun-factor-area bg-img pt-45 pb-80">
			<div class="container col-sm-12 col-md-12 col-12">
				<div class="row justify-content-between">
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter">9</span> %</h2>
						<h5>46 Tenaga</h5>
						<h2>CPNS</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter">1</span> %</h2>
						<h5>5 Tenaga</h5>
						<h2>MOU</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter">58</span> %</h2>
						<h5>300 Tenaga</h5>
						<h2>BLUD</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter">1</span> %</h2>
						<h5>2 Tenaga</h5>
						<h2>KONTRAK</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter">32</span> %</h2>
						<h5>171 Tenaga</h5>
						<h2>PNS</h2>
					</div>
					<!--Single Funfactor Area End-->
				</div>
			</div>
		</div>
	</div>
	<div class="Misi pt-65 pb-80">
	</div>
	<?php 
	$total = 0;
	foreach ($sdm->result() as $row) {
		$total+=intval($row->jumlah);
	}
		?>
	<div class="d_misi">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Jenis Sumber Daya Manusia</th>
					<th>Jumlah</th>
					<th>Presentase</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ($sdm->result() as $row) {?>
				<tr>
					<td><?php echo $row->jenis?></td>
					<td><font style="color: #105b50;"><?php echo $row->jumlah?></font></td>
					<td><?php echo number_format(($row->jumlah * 100)/$total,1);?>%</td>
				</tr>
			<?php } ?>
			</tbody>
			<tfoot>
				<tr>
					<th><h4>Total</h4></th>
					<td><font style="color: #105b50;"><h4><?php echo $total; ?></font></h4></td>
					<th></th>
				</tr>
			</tfoot>
		</table>
		<b>*update 1 September 2019</b>
	</div>
	
	<!--Brand Area End-->
<?php  $this->load->view('portal/template/footer'); ?>
	<!--Footer Area End-->
</div>

<!--Jquery 1.12.4-->
<?php $this->load->view('portal/template/footer_js'); ?>
</body>
</html>
