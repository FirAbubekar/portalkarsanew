<!doctype html>
<html class="no-js" lang="en">

<head>
	<?php $this->load->view('portal/template/header_css'); ?>
    <link rel="stylesheet" href="<?php echo base_url() ?>assets_portal/css/pendukung/struktur.css">
    
</head>

<body>
    <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

    <div class="wrapper">
        <!--Header Area Start-->
<?php $this->load->view('portal/template/menu'); ?>
        <!--Header Area End-->
        <!--Slider Area Start-->


        <!--Brand Area Start-->
        <div class="latest-blog-area pt-120blog">
            <img src="<?php echo base_url() ?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
        </div>

        <div class="visi">
            <div class="title1 pt-120blog">
                STRUKTUR ORGANISASI
            </div>
            <div class="d_visi">
                <img class="center" src="<?php echo base_url('file/struktur/struktur.png') ?>" alt="">
            </div>
        </div>
        <div class="Misi">
            <div class="title1 pt-120blog pb-85blog">
                DETAIL STRUKTUR ORGANISASI
            </div>
        </div>
        <div class="main">
        <?php 
        $this->db->where('urutan','0');
        $dbdir = $this->db->get('detail_struktur')->row();
        ?>
            <div class="row">
                <div class="column1">
                    <div class="col-md-12 col-sm-12 col-lg-12">
                    <div class="contents">
                    <p class="jabatann"><?php echo $dbdir->jabatan; ?></p>
                    <img class="center1" src="<?php echo base_url('file/struktur/'.$dbdir->gambar); ?>" alt="Mountains">
                    <div class="namaa"><?php echo $dbdir->nama; ?></div>
                    </div>
                </div>
            </div>

            <!-- END GRID -->
            <div class="row">
            <?php foreach ($struktur->result() as $row) { ?>
                <div class="column col-md-6 col-sm-12 col-lg-3">
                    <div class="content">
                        <img src="<?php echo base_url('file/struktur/'.$row->gambar); ?>" alt="" style="width:100%">
                        <div class="nama"><?php echo $row->nama; ?></div>
                        <p class="jabatan"><?php echo $row->jabatan; ?></p>
                    </div>
                </div>
            <?php } ?>
            </div>
                <!-- END GRID -->
            

            

        </div>

    </div>

    <!--Brand Area End-->
<?php  $this->load->view('portal/template/footer'); ?>
    <!--Footer Area End-->
    </div>

    <!--Jquery 1.12.4-->
    <?php $this->load->view('portal/template/footer_js'); ?>
</body>

</html>
