	<footer>
			<div class="footer-container">
				<!--Footer Top Area Start-->
				<div class="footer-top-area black-bg pt-100 pb-65">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-lg-8">
								<!--Single Footer Widget Start-->
								<div class="single-footer-widget mb-30">

									<a class="footer-logo" href="<?php echo base_url('home'); ?>"><img class="f_logo"
											src="<?php echo base_url();?>assets_portal/img/logo/logo-footer.png" alt=""></a>

									<p class="motto">Menjadi Rumah Sakit Pilihan Utama Masyarakat</p>
									<div class="single-footer-widget mb-30">
										<p><i><img src="<?php echo base_url();?>assets_portal/img/icon/ic_maps.png" alt=""></i> &nbsp;&nbsp;Jl. Achmad Yani No
											10-13,Kota Batu, Jawa Timur</p>
										<p class="contact-info"><i><img src="<?php echo base_url();?>assets_portal/img/icon/ic_call.png" alt=""></i>
											&nbsp;&nbsp;(0341) 596898, 591076, 591036</p>
										<p class="contact-info"><i><img src="<?php echo base_url();?>assets_portal/img/icon/ic_fax.png" alt=""></i>
											&nbsp;&nbsp;Fax. 596901 – 591076</p>
										<p class="contact-info"><i><img src="<?php echo base_url();?>assets_portal/img/icon/ic_envelope.png" alt=""></i>
											&nbsp;&nbsp;rsukhbatu@jatimprov.go.id</p>
									</div>
								</div>
								<h4 style="color: #fff;">Social Media</h4>
								<div class="sosmed col-md-12 col-lg-12">
									<a target="_blank" href="https://www.facebook.com/rsukarsahusadabatu">
									<img src="<?php echo base_url();?>assets_portal/img/icon/ic_facebook.png" alt="">
									</a>
									&nbsp;&nbsp;
									<a target="_blank" href="https://twitter.com/rsukhbatu">
									<img src="<?php echo base_url();?>assets_portal/img/icon/ic_twitter.png" alt="">
									</a>
									&nbsp;&nbsp;
									<a target="_blank" href="https://www.youtube.com/channel/UCekNeLXbwP5J-9Qfra_7lvw?view_as=subscriber">
									<img src="<?php echo base_url();?>assets_portal/img/icon/ic_youtube.png" alt="">
									</a>
									&nbsp;&nbsp;
									<a target="_blank" href="https://www.instagram.com/rsukarsahusadabatu/">
									<img src="<?php echo base_url();?>assets_portal/img/icon/ic_instagram.png" alt="">
									</a>
								</div>
								<!--Single Footer Widget End-->
							</div>
							<!--Single Footer Widget Start-->
							<div class="col-md-6 col-lg-4">
								<div class="single-footer-widget mb-30">
									<h3 class="footer-title">Tautan Lainnya</h3>
									<hr>
									<p><a target="_blank" style="color:white" href="http://rsukarsahusadabatu.jatimprov.go.id/daftaronline/">Pendaftaran Online</a></p>
									<p><a target="_blank" style="color:white" href="https://faskes.bpjs-kesehatan.go.id/aplicares/#/app/dashboard">Ketersediaan Kamar</p>
									<p><a target="_blank" style="color:white" href="https://rsukarsahusadabatu.jatimprov.go.id/komisi/">Registrasi Etik Penelitian Kesehatan</a></p>
									<p><a target="_blank" style="color:white" href="https://www.perpusnas.go.id/index.php?lang=id">Perpustakaan Nasional</p>
									<p><a target="_blank" style="color:white" href="https://rsukarsahusadabatu.jatimprov.go.id/ecomplaint/dashboard.php">E-Komplain</p>
								</div>
							</div>
							<!--Single Footer Widget End-->
						</div>
					</div>
				</div>
				<!--Footer Top Area End-->
				<!--Footer Bottom Area Start-->
				<div class="footer-bottom-area pt-20 pb-20">
					<div class="container text-center">
						<p>
							<font style="color: teal;"><span>&copy;</span>Rumah Sakit Karsa Husada <b>(SIRS)</b> Copyright© 2019. All Right Reserved</font>
						</p>
					</div>
				</div>
				<!--Footer Bottom Area End-->
			</div>
		</footer>