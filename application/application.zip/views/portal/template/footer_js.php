<script src="<?php echo base_url();?>assets_portal/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets_portal/js/vendor/jquery-1.12.4.min.js"></script>
<!--Waypoints-->
<script src="<?php echo base_url();?>assets_portal/js/waypoints.min.js"></script>
<!--Counterup-->
<script src="<?php echo base_url();?>assets_portal/js/jquery.counterup.min.js"></script>
<!--Carousel-->
<script src="<?php echo base_url();?>assets_portal/js/owl.carousel.min.js"></script>
<!--Meanmenu-->
<script src="<?php echo base_url();?>assets_portal/js/jquery.meanmenu.min.js"></script>
<!--Instafeed-->
<script src="<?php echo base_url();?>assets_portal/js/instafeed.min.js"></script>
<!--Datepicker-->
<script src="<?php echo base_url();?>assets_portal/js/jquery.datepicker.min.js"></script>
<!--Calendar-->
<script src="<?php echo base_url();?>assets_portal/js/zabuto-calendar.min.js"></script>
<!--ScrollUp-->
<script src="<?php echo base_url();?>assets_portal/js/jquery.scrollUp.min.js"></script>
<!--Wow-->
<script src="<?php echo base_url();?>assets_portal/js/wow.min.js"></script>
<!--Venobox-->
<script src="<?php echo base_url();?>assets_portal/js/venobox.min.js"></script>
<!--Popper-->
<script src="<?php echo base_url();?>assets_portal/js/popper.min.js"></script>
<!--Bootstrap-->
<script src="<?php echo base_url();?>assets_portal/js/bootstrap.min.js"></script>
<!--Plugins-->
<script src="<?php echo base_url();?>assets_portal/js/plugins.js"></script>
<!--Main Js-->
<script src="<?php echo base_url();?>assets_portal/js/main.js"></script>
