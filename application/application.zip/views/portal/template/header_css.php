<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>RSU Karsa Husada Batu</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Place favicon.ico in the root directory -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets_portal/img/karsa700.png">
	<!--All Css Here-->
	
	<!-- Droid Font CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/droid.css">
	<!-- Icofont CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/icofont.css">
	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/font-awesome.min.css">

	<!-- Animate CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/animate.css">
	<!-- Owl Carousel CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/owl.carousel.min.css">
	<!-- Datepicker CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/jquery.datepicker.css">
	<!-- Calendar CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/zabuto_calendar.css">
	<!-- Meanmenu CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/meanmenu.min.css">
	<!-- Venobox CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/venobox.css">
	<!-- Bootstrap CSS-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/bootstrap.min.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/responsive.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/bootstrap.css">
	
	
	<!-- Modernizr Js -->
	<script src="<?php echo base_url();?>assets_portal/js/vendor/modernizr-2.8.3.min.js"></script>