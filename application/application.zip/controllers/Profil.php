<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function sejarah()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= 'active';
		$data['s_sejarah'] 		= 'active';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= '';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->db->order_by('tahun','asc');
		$data['sejarah'] = $this->db->get('t_sejarah');

		$this->load->view('portal/sejarah',$data);
    }
    public function visimisi()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= 'active';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= 'active';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= '';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$data['visimisi']=$this->db->get('t_profil');
		$this->load->view('portal/visimisi',$data);
	}
	public function sdm()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= 'active';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= 'active';
		$data['s_struktur'] 	= '';
		$data['s_pelayanan']	= '';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->db->order_by('jumlah','desc');
		$this->db->where('status','1');
		$data['sdm'] = $this->db->get('t_sdm');

		$this->load->view('portal/sdm',$data);
    }
    public function struktur()
	{
		$data['s_beranda']		= '';
		$data['s_profil'] 		= 'active';
		$data['s_sejarah'] 		= '';
		$data['s_visi'] 		= '';
		$data['s_sdm'] 			= '';
		$data['s_struktur'] 	= 'active';
		$data['s_pelayanan']	= '';
		$data['s_unggulan'] 	= '';
		$data['s_igd'] 			= '';
		$data['s_rajal'] 		= '';
		$data['s_ranap'] 		= '';
		$data['s_penunjang']	= '';
		$data['s_tarif'] 		= '';
		$data['s_alur'] 		= '';
		$data['s_jadwal'] 		= '';
		$data['s_perpustakaan'] = '';
		$data['s_ppid'] 		= '';
		$data['s_informasi']	= '';
		$data['s_berita']		= '';
		$data['s_ikm']			= '';
		$data['s_mutu']			= '';
		$data['s_sakip']		= '';

		$this->db->where('status','1');
		$this->db->order_by('urutan','asc');
		$data['struktur'] = $this->db->get('detail_struktur');
		$this->load->view('portal/struktur',$data);
	}
}
