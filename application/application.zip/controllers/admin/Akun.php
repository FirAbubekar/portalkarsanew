<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akun extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
		
	}

	public function karyawan()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
        $datas['username'] = $this->session->userdata('username');

		$akun = $this->db->get('t_akun_karyawan');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_akun_karyawan');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_akun_karyawan');
		$data['nonaktif'] = $akun->num_rows();

		$data['akun'] = $this->db->get('t_akun_karyawan');

		$this->load->view('admin/akun_karyawan/tabel_akun_karyawan',$data);
	}

	public function save_akun(){
		if($this->input->post('submit')){
			$nip 		= $this->input->post('nip');
			$username 	= $this->input->post('username');
			$password 	= $this->input->post('password');
			$status 	= $this->input->post('status');

			$data = array('nip'			=> $nip,
						  'username'	=> $username,
						  'password'	=> $password,
						  'status'		=> $status
			);

			$this->db->insert('t_akun_karyawan',$data);

			$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Akun Karyawan, Dengan Username  = <b>".$username."</b>...");

			redirect('admin/akun/karyawan');
		}
	}

	public function edit_akun($id){
		if($this->input->post('submit')){
			$nip 		= $this->input->post('nip');
			$username 	= $this->input->post('username');
			$password 	= $this->input->post('password');
			$status 	= $this->input->post('status');

			$data = array('nip'			=> $nip,
						  'username'	=> $username,
						  'password'	=> $password,
						  'status'		=> $status
			);

			$this->db->where('id',$id);
			$this->db->update('t_akun_karyawan',$data);

			$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Akun Karyawan, Dengan Username  = <b>".$username."</b>...");

			redirect('admin/akun/karyawan');
		}
	}

	public function delete_akun($id){
		$this->db->where('id',$id);
		$this->db->delete('t_akun_karyawan');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Akun Karyawan");

		redirect('admin/akun/karyawan');
	}
	public function admin()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
		$datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= 'active';
		$data['a_admin']		= 'active';

		$akun = $this->db->get('t_akun_admin');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_akun_admin');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_akun_admin');
		$data['nonaktif'] = $akun->num_rows();

		$data['akun'] = $this->db->get('t_akun_admin');

		$this->load->view('admin/akun_admin/tabel_akun_admin',$data);
	}

	public function save_akun_admin(){
		if($this->input->post('submit')){
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$status = $this->input->post('status');

			$data = array('username'	=> $username,
						  'password'	=> $password,
						  'status'		=> $status
			);

			$this->db->insert('t_akun_admin',$data);

			$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Akun Admin, Dengan Username  = <b>".$username."</b>...");

			redirect('admin/akun/admin');
		}
	}

	public function edit_akun_admin($id){
		if($this->input->post('submit')){
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$status = $this->input->post('status');

			$data = array('username'	=> $username,
						  'password'	=> $password,
						  'status'		=> $status
			);

			$this->db->where('id',$id);
			$this->db->update('t_akun_admin',$data);

			$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Akun Admin, Dengan Username  = <b>".$username."</b>...");

			redirect('admin/akun/admin');
		}
	}

	public function delete_akun_admin($id){
		
		$this->db->where('id',$id);
		$d_username = $this->db->get('t_akun_admin')->row();
		
		$this->db->where('id',$id);
		$this->db->delete('t_akun_admin');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Akun Admin");

		redirect('admin/akun/admin');
	}
}
