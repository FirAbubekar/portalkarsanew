<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
	}

	public function index()
	{
        $datas['username'] = $this->session->userdata('username');

		$data['title'] = "Admin | RSU Karsa Husada";
		
		$data['a_dashboard']	= 'active';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$this->db->order_by('last_login','desc');
		$this->db->limit(10);
		$data['login'] = $this->db->get('t_akun_karyawan');

		$this->db->order_by('publikasi','desc');
		$this->db->limit(4);
		$data['berita'] = $this->db->get('t_berita');

		$this->db->order_by('id','desc');
		$this->db->limit(10);
		$data['visit'] = $this->db->get('t_visitor');

		$t_akun = $this->db->get('t_akun_karyawan');
		$data['akun'] = $t_akun->num_rows();

		$t_berita = $this->db->get('t_berita');
		$data['berita1'] = $t_berita->num_rows();

		$t_perpustakaan = $this->db->get('t_perpustakaan');
		$data['perpustakaan'] = $t_perpustakaan->num_rows();

		$t_pelayanan = $this->db->get('t_pelayanan');
		$data['pelayanan'] = $t_pelayanan->num_rows();

		$this->db->where('browser','Chrome');
		$t_chrome = $this->db->get('t_visitor');
		$data['chrome'] = $t_chrome->num_rows();

		$this->db->where('browser','Firefox');
		$t_firefox = $this->db->get('t_visitor');
		$data['firefox'] = $t_firefox->num_rows();

		$this->db->where('browser','Opera');
		$t_opera = $this->db->get('t_visitor');
		$data['opera'] = $t_opera->num_rows();

		$this->db->where('browser','Edge');
		$t_edge = $this->db->get('t_visitor');
		$data['edge'] = $t_edge->num_rows();

		$this->db->where('browser!=','Chrome');
		$this->db->where('browser!=','Opera');
		$this->db->where('browser!=','Firefox');
		$this->db->where('browser!=','Edge');
		$t_other = $this->db->get('t_visitor');
		$data['other'] = $t_other->num_rows();

		$t_browser = $this->db->get('t_visitor');
		$data['total'] = $t_browser->num_rows();

		$this->db->like('sistem_operasi','Windows');
		$t_windows = $this->db->get('t_visitor');
		$data['windows'] = $t_windows->num_rows();

		$this->db->like('sistem_operasi','Android');
		$t_android = $this->db->get('t_visitor');
		$data['android'] = $t_android->num_rows();

		$this->db->like('sistem_operasi','Linux');
		$t_linux = $this->db->get('t_visitor');
		$data['linux'] = $t_linux->num_rows();

		$this->db->like('sistem_operasi','Mac');
		$t_mac = $this->db->get('t_visitor');
		$data['mac'] = $t_mac->num_rows();

		$this->db->where('sistem_operasi!=','Windows');
		$this->db->where('sistem_operasi!=','Android');
		$this->db->where('sistem_operasi!=','Linux');
		$this->db->where('sistem_operasi!=','Mac');
		$t_other = $this->db->get('t_visitor');
		$data['other'] = $t_other->num_rows();

		$this->db->like('judul','LAYANAN UNGGULAN');
		$t_unggulan = $this->db->get('t_pelayanan');
		$data['unggulan'] = $t_unggulan->num_rows();

		$this->db->like('judul','INSTALASI RAWAT JALAN');
		$t_rajal = $this->db->get('t_pelayanan');
		$data['rajal'] = $t_rajal->num_rows();

		$this->db->like('judul','INSTALASI RAWAT INAP');
		$t_ranap = $this->db->get('t_pelayanan');
		$data['ranap'] = $t_ranap->num_rows();

		$this->db->like('judul','INSTALASI GAWAT DARURAT');
		$t_igd = $this->db->get('t_pelayanan');
		$data['igd'] = $t_igd->num_rows();

		$this->db->like('judul','PENUNJANG MEDIS');
		$t_medis = $this->db->get('t_pelayanan');
		$data['medis'] = $t_medis->num_rows();

		$this->db->like('judul','PENUNJANG NON MEDIS');
		$t_non = $this->db->get('t_pelayanan');
		$data['non'] = $t_non->num_rows();

		$this->load->view('admin/view_home',$data);
    }
    
}
