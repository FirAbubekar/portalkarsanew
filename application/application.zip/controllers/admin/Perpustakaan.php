<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perpustakaan extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
	}

	public function index()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
		
		$datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = 'active';
		$data['a_ppid'] 		= '';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$akun = $this->db->get('t_perpustakaan');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_perpustakaan');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_perpustakaan');
		$data['nonaktif'] = $akun->num_rows();
		
        $this->db->order_by('tanggal_upload','asc');
        $this->db->order_by('nama_file','asc');
		$data['perpustakaan'] = $this->db->get('t_perpustakaan');

		$this->load->view('admin/perpustakaan/tabel_perpustakaan',$data);
	}

	public function save()
	{
		date_default_timezone_set("Asia/Jakarta");
		$nama_file 	= $this->input->post('nama_file');
		$kategori 	= $this->input->post('kategori');
		$file 		= $this->input->post('link');
		$tanggal	= date('Y-m-d');
		$status 	= $this->input->post('status');

		$data		= array('nama_file'			=>$nama_file,
							'kategori'			=>$kategori,
							'tanggal_upload'	=>$tanggal,
							'file'				=>$file,
							'status'			=>$status);

		$this->db->insert('t_perpustakaan',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Perpustakaan, Dengan Nama File  = <b>".$nama_file."</b>...");

		redirect('admin/perpustakaan');
   }

   	public function edit($id){
	
		date_default_timezone_set("Asia/Jakarta");
		$this->db->where('id',$id);
		$dbperpustakaan = $this->db->get('t_perpustakaan')->row();


		$nama_file 	= $this->input->post('nama_file');
		$kategori 	= $this->input->post('kategori');
		$file 		= $this->input->post('link');
		$tanggal	= date('Y-m-d');
		$status 	= $this->input->post('status');

		$data		= array('nama_file'			=>$nama_file,
							'kategori'			=>$kategori,
							'tanggal_upload'	=>$tanggal,
							'file'				=>$file,
							'status'			=>$status);

		$this->db->where('id',$id);
		$this->db->update('t_perpustakaan',$data);
		
		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Perpustakaan, Dengan Nama File  = <b>".$nama_file."</b>...");

		redirect('admin/perpustakaan');
   }

   	public function delete($id){

   		$this->db->where('id',$id);
		$dbperpustakaan = $this->db->get('t_perpustakaan')->row();

		if ($dbperpustakaan->file!=null) {
			unlink('file/perpustakaan/'.$dbperpustakaan->file);
		}
		$this->db->where('id',$id);
		$this->db->delete('t_perpustakaan');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Perpustakaan");

		redirect('admin/perpustakaan');
   }
    
}
