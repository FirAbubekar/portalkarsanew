<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PPID extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek session login
		if($this->session->userdata('username') == ""){
			redirect(base_url("admin/login"));
		}
	}

	public function index()
	{
		$data['title'] = "Admin | RSU Karsa Husada";
		
		$datas['username'] = $this->session->userdata('username');
		
		$data['a_dashboard']	= '';
		$data['a_profil'] 		= '';
		$data['a_visi'] 		= '';
		$data['a_sejarah'] 		= '';
		$data['a_sdm'] 			= '';
		$data['a_organisasi'] 	= '';
		$data['a_pelayanan']	= '';
		$data['a_unggulan'] 	= '';
		$data['a_igd'] 			= '';
		$data['a_rajal'] 		= '';
		$data['a_ranap'] 		= '';
		$data['a_medis']	    = '';
		$data['a_nonmedis']	    = '';
		$data['a_tarif'] 		= '';
		$data['a_alur'] 		= '';
		$data['a_jadwal'] 		= '';
		$data['a_perpustakaan'] = '';
		$data['a_ppid'] 		= 'active';
		$data['a_informasi']	= '';
		$data['a_berita']		= '';
		$data['a_ikm']			= '';
		$data['a_mutu']			= '';
		$data['a_sakip']		= '';
		$data['a_akun']			= '';
		$data['a_admin']		= '';

		$akun = $this->db->get('t_ppid');
		$data['total'] = $akun->num_rows();

		$this->db->where('status','1');
		$akun = $this->db->get('t_ppid');
		$data['aktif'] = $akun->num_rows();

		$this->db->where('status','0');
		$akun = $this->db->get('t_ppid');
		$data['nonaktif'] = $akun->num_rows();

		$data['ppid'] = $this->db->get('t_ppid');

		$this->load->view('admin/ppid/tabel_ppid',$data);
	}

	public function save(){
		$judul   	= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$file = $judul;

		$uploadPath = mkdir('file/ppid/'.strtolower(str_replace(' ','_',$file)));
		$number_of_files = count($_FILES['gambar']['name']); 


		$data = array('judul'			=> $pelayanan,
					  'sub_judul'		=> $sub_title,
					  'waktu_pelayanan'	=> $jam,
					  'keterangan'		=> $keterangan,
					  'status'			=> $status);
		$this->db->insert('t_pelayanan',$data);
		$layanan = strtolower(str_replace(' ','-', $file));

		$this->db->limit('1');
		$this->db->order_by('id','desc');
		$dbppid = $this->db->get('t_ppid')->row();

		for ($i=0; $i < $number_of_files; $i++) { 

			$imageData = $this->upload->data();
				$gambar = substr($_FILES['gambar']['name'][$i],-4);
				$gambar = strtolower(str_replace(' ','_',$file."".$i."".$gambar));
				
		
			$_FILES['file']['name']       = $gambar;
            $_FILES['file']['type']       = $_FILES['gambar']['type'][$i];
            $_FILES['file']['tmp_name']   = $_FILES['gambar']['tmp_name'][$i];
            $_FILES['file']['error']      = $_FILES['gambar']['error'][$i];
			$_FILES['file']['size']       = $_FILES['gambar']['size'][$i];
			
            $config['upload_path'] = 'file/ppid/'.strtolower(str_replace(' ','_',$file));
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('file')){
				
				$imageData['file_name'][$i] = strtolower($file);
                $uploadImgData[$i]['gambar'] = $imageData['file_name'][$i];

            }

		$data1 = array('id_ppid'	=> $dbppid->id,
					   'gambar'			=> $gambar		
					 );
		$this->db->insert('detail_pelayanan',$data1);
		}

		$config['upload_path']          = 'file/ppid';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;
		
		$gambar = substr($_FILES['gambar']['name'],-4);
		$gambar = strtolower(str_replace(' ','_',$judul."".$gambar));
		$config['file_name'] 			= strtolower($judul);
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload('gambar')){
			$error = array('error' => $this->upload->display_errors());
		}else{
			$data = array('upload_data' => $this->upload->data());
		}
		
		$data		= array('judul'			=>$judul,
							'deskripsi'		=>$deskripsi,
							'gambar'		=>$gambar,
							'status'		=>$status);

		$this->db->insert('t_ppid',$data);

		$this->session->set_flashdata("success","<b>SAVE</b>.. Menambahkan Data Pada Menu Perpustakaan, Dengan Nama File  = <b>".$nama_file."</b>...");

		redirect('admin/ppid');
   	}

   	public function edit($id){

		$this->db->where('id',$id);
		$dbppid		= $this->db->get('t_ppid')->row();

		$judul   	= $this->input->post('judul');
		$deskripsi 	= $this->input->post('deskripsi');
		$status 	= $this->input->post('status');

		$config['upload_path']          = 'file/ppid';
		$config['allowed_types']        = 'pdf|docx|excel|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 2000;
		$config['max_height']           = 2000;

		if($_FILES['gambar']['name']==null){
			if($dbppid->gambar!=null){
				$gambar = $dbppid->gambar;
			}
		}
		else{
		unlink('file/ppid/'.$dbppid->gambar);
		$gambar = substr($_FILES['gambar']['name'],-4);
		$gambar = strtolower(str_replace(' ','_',$judul."".$gambar));
		$config['file_name'] 			= strtolower($judul);
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload('gambar')){
			$error = array('error' => $this->upload->display_errors());
		}else{
			
			$data = array('upload_data' => $this->upload->data());
		}
		}
	
		$data		= array('judul'			=>$judul,
							'deskripsi'		=>$deskripsi,
							'gambar'		=>$gambar,
							'status'		=>$status);
	

		$this->db->where('id',$id);
		$this->db->update('t_ppid',$data);

		$this->session->set_flashdata("update","<b>UPDATE</b>.. Merubah Data Pada Menu Perpustakaan, Dengan Nama File  = <b>".$nama_file."</b>...");

		redirect('admin/ppid');
	}

  	public function delete($id){
		$this->db->where('id',$id);
		$this->db->delete('t_ppid');

		$this->session->set_flashdata("delete","<b>DELETE</b>.. Menghapus Data Pada Menu Perpustakaan");

		redirect('admin/ppid');
   	}
    
}
