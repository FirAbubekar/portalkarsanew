<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php $this->load->view('portal/template/header_css');?>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets_portal/css/pendukung/tarif.css">
</head>

<body>
    <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div class="wrapper">
    <!--Header Area Start-->
    <?php $this->load->view('portal/template/menu');?>
    <!--Header Area End-->
    <!--Brand Area Start-->
    <div class="latest-blog-area pt-120blog">
        <img src="<?php echo base_url(); ?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
    </div>
      <div class="title">
        <h2>TARIF PELAYANAN</h2>
        <hr>
    </div>
    <div class="sub_title">
        <h3>INSTALASI GAWAT DARURAT (IGD)</h3>
        <hr>
    </div>
    <div class="d_misi">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Jenis Pelayanan</th>
                    <th>Tarif</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($igd->result() as $row) { ?>
                <tr>
                    <td><?php echo $row->jenis_pelayanan; ?></td>
                    <td><?php echo $row->tarif; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div class="sub_title">
        <h3>RAWAT JALAN</h3>
        <hr>
    </div>
    <div class="d_misi">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Jenis Pelayanan</th>
                    <th>Rawat Jalan</th>
                    <th>Executive</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rajal->result() as $row) { ?>
                <tr>
                    <td><?php echo $row->jenis_pelayanan; ?></td>
                    <td><?php echo $row->tarif_rajal; ?></td>
                    <td><?php echo $row->executive; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div class="sub_title">
        <h3>RAWAT INAP</h3>
        <hr>
    </div>
    <div class="d_misi overflow-x:auto;">
        <table style="width: 100%;" class="table table-hover">
            <thead>
                <tr>
                    <th>Jenis Pelayanan</th>
                    <th>Kelas III</th>
                    <th>Kelas II</th>
                    <th>Kelas I</th>
                    <th>Kelas Utama</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ranap->result() as $row) { ?>
                <tr>
                    <td><?php echo $row->jenis_pelayanan; ?></td>
                    <td><?php echo $row->kelas3; ?></td>
                    <td><?php echo $row->kelas2; ?></td>
                    <td><?php echo $row->kelas1; ?></td>
                    <td><?php echo $row->kelas_utama; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <!--Brand Area End-->
    <?php $this->load->view('portal/template/footer');?>
            <!--Footer Area End-->
        </div>

        <!--Jquery 1.12.4-->
       <?php $this->load->view('portal/template/footer_js');?>
    </body>

    </html>
