<!doctype html>
<html class="no-js" lang="en">
<head>
	<?php $this->load->view('portal/template/header_css'); ?>
	<link rel="stylesheet" href="<?php echo base_url();?>assets_portal/css/pendukung/profil.css">
	
</head>
<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div class="wrapper">
	<!--Header Area Start-->
    <?php $this->load->view('portal/template/menu');?>
	<!--Brand Area Start-->
	<div class="latest-blog-area pt-120blog">
		<img src="<?php echo base_url();?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
	</div>
	
	<?php foreach ($tugasfungsi->result() as $row) { ?>
	<div class="visi">
		<div class="title1 pt-120blog">
			<h1><?php echo $row->subjudul;?></h1>
		</div>
		<div class="d_visi">
			<?php echo $row->deskripsi; ?>
		</div>
	</div>
	<?php } ?>
	<!-- <div class="Misi">
		<div class="title1 pt-120blog pb-85blog">
			<h1>Misi</h1>
		</div>
	</div>
	<div class="d_misi">
		<p>
			<font size="4" style="color: rgba(0, 0, 0, 0.7);">
				<ol>
					<li class="n_visi">Mewujudkan pelayanan kesehatan aman, ramah dan berkualitas.</li>
					<li class="n_visi">Mewujudkan tatakelola rumah sakit yang profesional dan akuntabel.</li>
					<li class="n_visi">Mewujudkan rumah sakit umum karsa husada batu sebagai rsu kelas b Pendidikan</li>
				</ol>
			</font>
		</p>
	</div>
	 -->
	<!--Brand Area End-->
<?php  $this->load->view('portal/template/footer'); ?>
	<!--Footer Area End-->
</div>
<?php $this->load->view('portal/template/footer_js'); ?>
</body>
</html>
