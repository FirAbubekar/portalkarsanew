<!doctype html>
<html class="no-js" lang="en">
<head>
	<?php $this->load->view('portal/template/header_css'); ?>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets_portal/css/pendukung/sdm.css">
</head>
<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div class="wrapper">
	<!--Header Area Start-->
	<?php $this->load->view('portal/template/menu'); ?>
	<!--Header Area End-->
	<!--Slider Area Start-->
	
	
	<!--Brand Area Start-->
	<div class="latest-blog-area pt-120blog">
		<img src="<?php echo base_url() ?>assets_portal/img/bg/head2.png" style="width: 100%;" alt="">
	 	</div>
	<div class="visi">
		<div class="title1 pt-120blog">
			<h1>Sumber Daya Manusia</h1>
		</div>
		<div class="fun-factor-area bg-img pt-45 pb-80">
			<div class="container col-sm-12 col-md-12 col-12">
				<div class="row justify-content-between">
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($subsdm->pns/$subsdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $subsdm->pns; ?> Tenaga</h5>
						<h2>CPNS</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($subsdm->blud/$subsdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $subsdm->blud; ?> Tenaga</h5>
						<h2>BLUD</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($subsdm->mou/$subsdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $subsdm->mou; ?> Tenaga</h5>
						<h2>MoU</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-6 col-lg-2 fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($subsdm->kontrak/$subsdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $subsdm->kontrak; ?> Tenaga</h5>
						<h2>KONTRAK</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<!--Single Funfactor Area End-->
				</div>
			</div>
		</div>
	
	<div class="Misi pt-65 pb-80">
	</div>
	<?php 
	$total = 0;
	foreach ($sdm->result() as $row) {
		$total+=intval($row->jumlah);
	}
		?>
	<div class="d_misi">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Jenis Sumber Daya Manusia</th>
					<th>Jumlah</th>
					<th>Presentase</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ($sdm->result() as $row) {?>
				<tr>
					<td><?php echo $row->jenis?></td>
					<td><font style="color: #105b50;"><?php echo $row->jumlah?></font></td>
					<td><?php echo number_format(($row->jumlah * 100)/$total,1);?>%</td>
				</tr>
			<?php } ?>
			</tbody>
			<tfoot>
				<tr>
					<th><h4>Total</h4></th>
					<td><font style="color: #105b50;"><h4><?php echo $total; ?></font></h4></td>
					<th></th>
				</tr>
			</tfoot>
		</table>
		</div>
		<div class="visi">
		<div class="title1 pt-120blog">
			<h1>Pendidikan SDM</h1>
		</div>
		<style>
			.col-lg-2 {
                width: 14.2857143%;
            }
		</style>
		<div class="fun-factor-area bg-img pt-45 pb-80">
			<div class="container col-sm-12 col-md-12 col-12">
				<div class="row justify-content-between">
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->s2/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->s2; ?> Tenaga</h5>
						<h2>S2</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->s1/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->s1; ?> Tenaga</h5>
						<h2>S1</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->d4/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->d4; ?> Tenaga</h5>
						<h2>D4</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->d3/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->d3; ?> Tenaga</h5>
						<h2>D3</h2>
					</div>

					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->d2/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->d2; ?> Tenaga</h5>
						<h2>D2</h2>
					</div>

					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->d1/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->d1; ?> Tenaga</h5>
						<h2>D1</h2>
					</div>

					<div class="col-sm-12 col-md-12 col-lg-1  fun-factor-wrap1">
						<h2><span class="counter"><?php echo number_format((($pendidikansdm->sma/$pendidikansdm->jumlah)*100),1); ?></span> %</h2>
						<h5><?php echo $pendidikansdm->sma; ?> Tenaga</h5>
						<h2>SMA</h2>
					</div>
					<!--Single Funfactor Area End-->
					<!--Single Funfactor Area Start-->
					<!--Single Funfactor Area End-->
				</div>
			</div>
		</div>
	</div>
	<br><br><br>
	<div class="d_misi">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Pendidikan Sumber Daya Manusia</th>
					<th>S2</th>
					<th>S1</th>
					<th>D4</th>
					<th>D3</th>
					<th>D2</th>
					<th>D1</th>
					<th>SMA</th>
					<th>Total</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ($sdm->result() as $row) {
				$totalkanan = $row->s2+$row->s1+$row->d4+$row->d3+$row->d2+$row->d1+$row->sma;
				?>
				<tr>
					<td><?php echo $row->jenis?></td>
					<td><font style="color: #105b50;"><?php echo $row->s2?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->s1?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->d4?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->d3?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->d2?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->d1?></font></td>
					<td><font style="color: #105b50;"><?php echo $row->sma?></font></td>
					<td><?php echo $totalkanan;?></td>
				</tr>
			<?php } ?>
			</tbody>
			<tfoot>
				<tr>
					<th><h4>Total</h4></th>
					<th><?php echo $pendidikansdm->s2; ?> </th>
					<th><?php echo $pendidikansdm->s1; ?> </th>
					<th><?php echo $pendidikansdm->d4; ?> </th>
					<th><?php echo $pendidikansdm->d3; ?> </th>
					<th><?php echo $pendidikansdm->d2; ?> </th>
					<th><?php echo $pendidikansdm->d1; ?> </th>
					<th><?php echo $pendidikansdm->sma; ?> </th>
					<th><?php echo $pendidikansdm->s2+$pendidikansdm->s1+$pendidikansdm->d4+$pendidikansdm->d3+$pendidikansdm->d2+$pendidikansdm->d1+$pendidikansdm->sma; ?> </th>
				</tr>
			</tfoot>
		</table>
		</div>
		<!-- <b>*update 1 September 2019</b> -->
	</div>
	
	<!--Brand Area End-->
<?php  $this->load->view('portal/template/footer'); ?>
	<!--Footer Area End-->
</div>

<!--Jquery 1.12.4-->
<?php $this->load->view('portal/template/footer_js'); ?>
</body>
</html>
