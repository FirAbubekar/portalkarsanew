

  <!-- <style>

    html, body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
      font-size: 14px;
    }

    #calendar {
      width: 100%;
      
    }
    .about-content > p {
    font-size: 16px;
    line-height: 25px;
    color: #5d5d5d;
    margin-bottom: 30px;
}

  </style> -->



  <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.7.0/main.min.css' rel='stylesheet' />
  <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.7.0/main.min.js'></script>


<style>

  html, body {
    margin: 0;
    padding: 0;
    font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
    font-size: 14px;
  }

  #calendar {
    width: 100%;
    height:100%;
    margin: 20px auto;
  }
  .fc .fc-scroller-harness-liquid {
    height: 100%;
}
</style>

<!-- 
<link href='https://unpkg.com/@fullcalendar/core@4.3.1/main.min.css' rel='stylesheet' />


<link href='https://unpkg.com/@fullcalendar/daygrid@4.3.0/main.min.css' rel='stylesheet' />



<script src='https://unpkg.com/@fullcalendar/core@4.3.1/main.min.js'></script>




<script src='https://unpkg.com/@fullcalendar/daygrid@4.3.0/main.min.js'></script>
  

  



<script src='/assets/demo-to-codepen.js'></script>

 -->

  <script>

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      selectable: true,
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay'
      },
      events: '<?php echo base_url('Home/getkegiatan');?>',
      dateClick: function(info) {
        getkegiatan(info.dateStr);
      },
      select: function(info,id) {
        // alert('selected ' + info.startStr + ' to ' + info.endStr);
        // var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
        // var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
      }
    });

    calendar.render();
  });

  function getkegiatan(tglkegiatan){
		$.ajax({
				url: "<?php echo base_url(); ?>home/getdetailkegiatan",
				method: "POST",
				data: {
					tglkegiatan: tglkegiatan
				},
				async: false,
				dataType: 'json',
				success: function (data) {
                    console.log(data)
                    var html = '';
					var i;

                    for (i = 0; i < data.length;i++) {
                        dArr = data[i].tgl_mulai.split("-");  // ex input "2010-01-18"
                        dArr = dArr[2]+ "/" +dArr[1]+ "/" +dArr[0];
                        html += '<div class="about-content"><div  id="nama_kegiatan" class="sub_title" style="color: #005145; font-size: 16pt;">- '+data[i].nama_kegiatan+'</div><span><font style="color: #005145; font-size: 14pt;">Lokasi Kegiatan = '+data[i].lokasi+'</font></span><br><span><font style="color: #005145; font-size: 14pt;">Tanggal Kegiatan = '+dArr+'</font></span><br>Deskripsi : <p style="font-color: #4c4c4c; font-size: 15pt;">'+data[i].deskripsi+'</p></div>';
                    }
                    $('#detail_kegiatan').html(html);
                //    alert(data);
					// $("#nama_kegiatan").html(data.nama_kegiatan);
					// $("#norekamedis").val(data.noRekamedis);
					// $("#nmpasien").val(data.nmPasien);
					// $("#tgltindakan").val(data.tglTindakan);
					// detailtindakan(data.kdSesi,data.kdBed);
					// tabeltindakan(data.noTindakanHD);
					// // $("#sesitindakan").val(data.kdSesi);
					// // $("#bedtindakan").val(data.kdBed);
					// $("#pakettindakan").val(data.kdPaket);
					// $("#jenispaket").val(data.kdJenisPaket);
				}
			})
	}

</script>

</head>
<body>
    <div class='demo-topbar'>
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div id="detail_kegiatan"></div>
        </div>  
    </div>

  <div id='calendar'></div>
</body>

</html>